/*
	Jeremy Horan & Geoff Shapiro
	Maze Project
	May 14th 2013
	An aMAZEing maze game with optional features
*/

#include "Maze.h"

using namespace std;

void main()
{
	Maze aMaze;

	aMaze.Play();
}